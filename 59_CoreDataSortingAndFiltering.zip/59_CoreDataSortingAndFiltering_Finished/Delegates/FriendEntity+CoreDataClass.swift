//
//  FriendEntity+CoreDataClass.swift
//  Delegates
//
//  Created by Daniel Lauer on 11/12/16.
//  Copyright © 2016 Daniel Lauer. All rights reserved.
//

import Foundation
import CoreData

@objc(FriendEntity)
public class FriendEntity: NSManagedObject {

}
