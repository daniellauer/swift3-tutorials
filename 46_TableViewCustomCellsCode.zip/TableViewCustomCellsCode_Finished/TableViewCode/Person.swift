//
//  Person.swift
//  TableViewCode
//
//  Created by Daniel Lauer on 30/11/16.
//  Copyright © 2016 Daniel Lauer. All rights reserved.
//

import Foundation

struct Person {
    var name: String
    var personImageName: String
    var flagImageName: String
}
