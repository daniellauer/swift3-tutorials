//: [Previous](@previous)

import Foundation

let str = "Hello, playground"
let myString: String = "Hello"

