//: Playground - noun: a place where people can play

import UIKit

var str = "Hello, playground"
var str2 = "H"
var int = 5
var float = 5.5
var bool = true

// I'm a comment
var myString: String = "Hello"
var myCharacter: Character = "H"

var myBool: Bool = false // true

//var myInteger: Int = 5
var myUnsignedInteger: UInt = 5

var myFloat: Float = 5.5
var myDouble: Double = 5.5

/*
var myInteger8: Int8 = 5
var myUnsignedInteger8: UInt8 = 5
/*
var myInteger16: Int16 = 5
var myUnsignedInteger16: UInt16 = 5

var myInteger32: Int32 = 5
var myUnsignedInteger32: UInt32 = 5
*/
var myInteger64: Int64 = 5
var myUnsignedInteger64: UInt64 = 5
 */
