//
//  Friend.swift
//  Delegates
//
//  Created by Daniel Lauer on 03/12/16.
//  Copyright © 2016 Daniel Lauer. All rights reserved.
//

import Foundation


struct Friend {
    var name: String
    var imageName: String
}
